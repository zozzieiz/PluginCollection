--------------------------------------------------------------------------------

Copyright (C) 2013-2016 Gonçalo Baltazar <me@goncalomb.com>

NBTEditor ${project.version}

----- LICENCE NOTICE -----------------------------------------------------------

NBTEditor is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

NBTEditor is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with NBTEditor.  If not, see <http://www.gnu.org/licenses/>.

----- BUILD INFORMATION --------------------------------------------------------

NBTEditor ${project.version}

Build Date: ${project.build.timestamp}
Bukkit API Version: ${bukkit.version}

os.name = ${os.name}
os.version = ${os.version}
os.arch = ${os.arch}
java.version = ${java.version}
java.vendor = ${java.vendor}
maven.version = ${maven.version}
maven.build.version = ${maven.build.version}

----- SOFTWARE INFORMATION -----------------------------------------------------

For more information and help, check
http://dev.bukkit.org/bukkit-plugins/nbteditor/

--------------------------------------------------------------------------------
